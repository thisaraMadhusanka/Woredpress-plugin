jQuery(document).ready(function($) {
    $('.ac-media-upload').click(function(e) {
        e.preventDefault();
        var button = $(this);
        var customUploader = wp.media({
            title: 'Select Image',
            library: { type: 'image' },
            button: { text: 'Use This Image' },
            multiple: false
        }).on('select', function() {
            var attachment = customUploader.state().get('selection').first().toJSON();
            button.siblings('input[type="text"]').val(attachment.url);
        }).open();
    });
});

// jQuery(document).ready(function($) {
//     // Check if the success message exists
//     if ($('.notice.notice-success').length > 0) {
//         // Reset the form fields
//         $('form').trigger('reset');

//         // Clear specific fields like profile image
//         $('#ac_image_url').val('');

//         // Optionally, scroll to the top of the page
//         $('html, body').animate({ scrollTop: 0 }, 'slow');
//     }

//     // Media Upload Button
//     $('.ac-media-upload').click(function(e) {
//         e.preventDefault();
//         const button = $(this);
//         const customUploader = wp.media({
//             title: 'Select Image',
//             library: { type: 'image' },
//             button: { text: 'Use This Image' },
//             multiple: false
//         }).on('select', function() {
//             const attachment = customUploader.state().get('selection').first().toJSON();
//             button.siblings('input').val(attachment.url);
//         }).open();
//     });
// });