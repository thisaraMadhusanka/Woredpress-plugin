<?php
if (!defined('ABSPATH')) exit;

class AC_Entries_Widget extends \Elementor\Widget_Base {

    public function get_name() { return 'ac_entries'; }
    public function get_title() { return 'CRUD Entries'; }
    public function get_icon() { return 'eicon-post-list'; }
    public function get_categories() { return ['advanced-crud']; }

    protected function register_controls() {
        // Content Section
        $this->start_controls_section('content_section', [
            'label' => 'Content',
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT
        ]);

        $this->add_control('per_page', [
            'label' => 'Entries Per Page',
            'type' => \Elementor\Controls_Manager::NUMBER,
            'default' => 5
        ]);

        $this->add_control('show_image', [
            'label' => 'Show Image',
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'default' => 'yes'
        ]);

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section('style_section', [
            'label' => 'Style',
            'tab' => \Elementor\Controls_Manager::TAB_STYLE
        ]);

        $this->add_control('item_background', [
            'label' => 'Item Background',
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => ['{{WRAPPER}} .ac-entry-item' => 'background-color: {{VALUE}};']
        ]);

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .ac-entry-title'
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        global $wpdb;
        $settings = $this->get_settings_for_display();
        $table = $wpdb->prefix . 'advanced_crud';
        
        $paged = max(1, get_query_var('paged'));
        $offset = ($paged - 1) * $settings['per_page'];
        
        $entries = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table 
            ORDER BY created_at DESC 
            LIMIT %d OFFSET %d",
            $settings['per_page'],
            $offset
        ));

        $total = $wpdb->get_var("SELECT COUNT(*) FROM $table");
        $pages = ceil($total / $settings['per_page']);

        echo '<div class="ac-entries-list">';
        if ($entries) {
            foreach ($entries as $entry) {
                echo '<div class="ac-entry-item">';
                if ($settings['show_image'] === 'yes') {
                    echo '<img src="' . esc_url($entry->profile_image) . '" class="ac-entry-image">';
                }
                echo '<div class="ac-entry-content">';
                echo '<h3 class="ac-entry-title">' . esc_html($entry->name) . '</h3>';
                echo '<div class="ac-entry-meta">';
                echo '<span class="ac-entry-email">' . esc_html($entry->email) . '</span>';
                echo '<span class="ac-entry-phone">' . esc_html($entry->phone) . '</span>';
                echo '</div>';
                echo '<p class="ac-entry-address">' . esc_html($entry->address) . '</p>';
                echo '</div></div>';
            }
            
            echo '<div class="ac-pagination">';
            echo paginate_links([
                'base' => str_replace(999999999, '%#%', esc_url(get_pagenum_link(999999999))),
                'format' => '?paged=%#%',
                'current' => $paged,
                'total' => $pages
            ]);
            echo '</div>';
        } else {
            echo '<p class="ac-no-entries">No entries found</p>';
        }
        echo '</div>';
    }
}

class AC_Form_Widget extends \Elementor\Widget_Base {

    public function get_name() { return 'ac_form'; }
    public function get_title() { return 'CRUD Form'; }
    public function get_icon() { return 'eicon-form-horizontal'; }
    public function get_categories() { return ['advanced-crud']; }

    protected function register_controls() {
        $this->start_controls_section('content_section', [
            'label' => 'Content',
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT
        ]);

        $this->add_control('form_title', [
            'label' => 'Form Title',
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => 'Add New Entry'
        ]);

        $this->end_controls_section();
    }

    protected function render() {
        global $wpdb;
        $table = $wpdb->prefix . 'advanced_crud';

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ac_nonce'])) {
            if (wp_verify_nonce($_POST['ac_nonce'], 'ac_form_nonce')) {
                $data = [
                    'name' => sanitize_text_field($_POST['ac_name']),
                    'email' => sanitize_email($_POST['ac_email']),
                    'address' => sanitize_textarea_field($_POST['ac_address']),
                    'phone' => sanitize_text_field($_POST['ac_phone']),
                    'profile_image' => esc_url_raw($_POST['ac_image']),
                    'created_at' => current_time('mysql')
                ];

                $wpdb->insert($table, $data);
                echo '<div class="ac-success">Entry added successfully!</div>';
            }
        }

        echo '<div class="ac-form-wrapper">';
        echo '<h3>' . esc_html($this->get_settings('form_title')) . '</h3>';
        echo '<form method="post">';
        wp_nonce_field('ac_form_nonce', 'ac_nonce');
        echo '<div class="ac-form-group">';
        echo '<input type="text" name="ac_name" placeholder="Full Name" required>';
        echo '</div>';
        echo '<div class="ac-form-group">';
        echo '<input type="email" name="ac_email" placeholder="Email Address" required>';
        echo '</div>';
        echo '<div class="ac-form-group">';
        echo '<textarea name="ac_address" placeholder="Address" required></textarea>';
        echo '</div>';
        echo '<div class="ac-form-group">';
        echo '<input type="tel" name="ac_phone" placeholder="Phone Number" required>';
        echo '</div>';
        echo '<div class="ac-form-group">';
        echo '<input type="url" name="ac_image" id="ac_image_url" placeholder="Image URL" required>';
        echo '<button type="button" class="ac-media-upload" data-target="#ac_image_url">Upload Image</button>';
        echo '</div>';
        echo '<button type="submit" class="ac-submit-button">Submit</button>';
        echo '</form></div>';
    }
}

\Elementor\Plugin::instance()->widgets_manager->register(new AC_Entries_Widget());
\Elementor\Plugin::instance()->widgets_manager->register(new AC_Form_Widget());