<?php
if (!defined('ABSPATH')) exit;

class AC_Entries_Widget extends \Elementor\Widget_Base {

    public function get_name() { return 'ac_entries'; }
    public function get_title() { return 'CRUD Entries'; }
    public function get_icon() { return 'eicon-post-list'; }
    public function get_categories() { return ['advanced-crud']; }

    protected function register_controls() {
        // Content Section
        $this->start_controls_section('content_section', [
            'label' => 'Content',
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT
        ]);

        $this->add_control('per_page', [
            'label' => 'Entries Per Page',
            'type' => \Elementor\Controls_Manager::NUMBER,
            'default' => 5
        ]);

        $this->add_control('show_image', [
            'label' => 'Show Image',
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'default' => 'yes'
        ]);

        $this->add_control('show_social', [
            'label' => 'Show Social Media',
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'default' => 'yes'
        ]);


        $this->end_controls_section();

        // Style Section
        $this->start_controls_section('style_section', [
            'label' => 'Style',
            'tab' => \Elementor\Controls_Manager::TAB_STYLE
        ]);

        $this->add_control('item_background', [
            'label' => 'Item Background',
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => ['{{WRAPPER}} .ac-entry-item' => 'background-color: {{VALUE}};']
        ]);

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .ac-entry-title'
            ]
        );
  // Image Controls
            $this->add_control('image_style', [
                'label' => 'Image Style',
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before'
            ]);
    
            $this->add_control('image_size', [
                'label' => 'Size',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => ['min' => 50, 'max' => 200]
                ],
                'default' => ['unit' => 'px', 'size' => 80],
                'selectors' => [
                    '{{WRAPPER}} .ac-entry-image' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};'
                ]
            ]);
    
            $this->add_control('image_border_radius', [
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    '%' => ['min' => 0, 'max' => 50]
                ],
                'selectors' => [
                    '{{WRAPPER}} .ac-entry-image' => 'border-radius: {{SIZE}}%;'
                ]
            ]);
    
   // Image Position
   $this->add_control(
    'image_position',
    [
        'label' => __('Image Position', 'plugin-name'),
        'type' => \Elementor\Controls_Manager::CHOOSE,
        'options' => [
            'left' => [
                'title' => __('Left', 'plugin-name'),
                'icon' => 'eicon-h-align-left',
            ],
            'center' => [
                'title' => __('Center', 'plugin-name'),
                'icon' => 'eicon-text-align-center',
            ],
            'right' => [
                'title' => __('Right', 'plugin-name'),
                'icon' => 'eicon-h-align-right',
            ],
        ],
        'default' => 'center',
        'toggle' => true,
    ]
);

// Alignment
$this->add_control(
    'content_alignment',
    [
        'label' => __('Alignment', 'plugin-name'),
        'type' => \Elementor\Controls_Manager::CHOOSE,
        'options' => [
            'left' => [
                'title' => __('Left', 'plugin-name'),
                'icon' => 'eicon-text-align-left',
            ],
            'center' => [
                'title' => __('Center', 'plugin-name'),
                'icon' => 'eicon-text-align-center',
            ],
            'right' => [
                'title' => __('Right', 'plugin-name'),
                'icon' => 'eicon-text-align-right',
            ],
        ],
        'default' => 'left',
        'toggle' => true,
    ]
);

// Image Spacing
$this->add_responsive_control(
    'image_spacing',
    [
        'label' => __('Image Spacing', 'plugin-name'),
        'type' => \Elementor\Controls_Manager::SLIDER,
        'size_units' => ['px'],
        'range' => [
            'px' => [
                'min' => 0,
                'max' => 50,
            ],
        ],
        'default' => [
            'size' => 15,
            'unit' => 'px',
        ],
        'selectors' => [
            '{{WRAPPER}} .ac-entry-image' => 'margin-bottom: {{SIZE}}{{UNIT}};',
        ],
    ]
);

 // Content Spacing
 $this->add_responsive_control(
    'content_spacing',
    [
        'label' => __('Content Spacing', 'plugin-name'),
        'type' => \Elementor\Controls_Manager::SLIDER,
        'size_units' => ['px'],
        'range' => [
            'px' => [
                'min' => 0,
                'max' => 50,
            ],
        ],
        'default' => [
            'size' => 15,
            'unit' => 'px',
        ],
        'selectors' => [
            '{{WRAPPER}} .ac-entry-content' => 'padding: {{SIZE}}{{UNIT}};',
        ],
    ]
);


            // Text Controls
            $this->add_control('text_style', [
                'label' => 'Text Style',
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before'
            ]);
    
            $this->add_group_control(\Elementor\Group_Control_Typography::get_type(), [
                'name' => 'name_typography',
                'label' => 'Name Typography',
                'selector' => '{{WRAPPER}} .ac-entry-title'
            ]);
    
            $this->add_control('name_color', [
                'label' => 'Name Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} .ac-entry-title' => 'color: {{VALUE}};']
            ]);
    
    //address color
    $this->add_group_control(\Elementor\Group_Control_Typography::get_type(), [
        'name' => 'address_typography',
        'label' => 'Address Typography',
        'selector' => '{{WRAPPER}} .ac-entry-address'
    ]);

    $this->add_control('address_color', [
        'label' => 'Address Color',
        'type' => \Elementor\Controls_Manager::COLOR,
        'selectors' => ['{{WRAPPER}} .ac-entry-address' => 'color: {{VALUE}};']
    ]);

//Email color 
$this->add_group_control(\Elementor\Group_Control_Typography::get_type(), [
    'name' => 'email_typography',
    'label' => 'Email Typography',
    'selector' => '{{WRAPPER}} .ac-entry-email'
]);

$this->add_control('email_color', [
    'label' => 'Email Color',
    'type' => \Elementor\Controls_Manager::COLOR,
    'selectors' => ['{{WRAPPER}} .ac-entry-email' => 'color: {{VALUE}};']
]);

//phone color 
$this->add_group_control(\Elementor\Group_Control_Typography::get_type(), [
    'name' => 'phone_typography',
    'label' => 'Phone Number Typography',
    'selector' => '{{WRAPPER}} .ac-entry-phone'
]);

$this->add_control('phonenumber_color', [
    'label' => 'Phone Number Color',
    'type' => \Elementor\Controls_Manager::COLOR,
    'selectors' => ['{{WRAPPER}} .ac-entry-phone' => 'color: {{VALUE}};']
]);
  // Image Controls
  $this->add_control('icon_style', [
    'label' => 'Icon Style',
    'type' => \Elementor\Controls_Manager::HEADING,
    'separator' => 'before'
]);

// Icon Color Control
$this->add_control(
    'social_icon_color',
    [
        'label'     => __('Icon Color', 'your-plugin-textdomain'),
        'type'      => \Elementor\Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .ac-social-links a' => 'color: {{VALUE}};',
        ],
    ]
);

// Background Color Control
$this->add_control(
    'social_icon_background',
    [
        'label'     => __('Background Color', 'your-plugin-textdomain'),
        'type'      => \Elementor\Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .ac-social-links a' => 'background-color: {{VALUE}};',
        ],
    ]
);

// Hover Icon Color Control
$this->add_control(
    'social_icon_hover_color',
    [
        'label'     => __('Hover Icon Color', 'your-plugin-textdomain'),
        'type'      => \Elementor\Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .ac-social-links a:hover' => 'color: {{VALUE}};',
        ],
    ]
);

// Hover Background Color Control
$this->add_control(
    'social_icon_hover_background',
    [
        'label'     => __('Hover Background Color', 'your-plugin-textdomain'),
        'type'      => \Elementor\Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .ac-social-links a:hover' => 'background-color: {{VALUE}};',
        ],
    ]
);

// Icon Size Control
$this->add_responsive_control(
    'social_icon_size',
    [
        'label'      => __('Icon Size', 'your-plugin-textdomain'),
        'type'       => \Elementor\Controls_Manager::SLIDER,
        'size_units' => ['px'],
        'range'      => [
            'px' => [
                'min' => 10,
                'max' => 50,
            ],
        ],
        'selectors'  => [
            '{{WRAPPER}} .ac-social-links a i' => 'font-size: {{SIZE}}{{UNIT}};',
        ],
    ]
);
// Border Radius Control
$this->add_responsive_control(
    'social_icon_border_radius',
    [
        'label'      => __('Border Radius', 'your-plugin-textdomain'),
        'type'       => \Elementor\Controls_Manager::SLIDER,
        'size_units' => ['px', '%'],
        'range'      => [
            'px' => [
                'min' => 0,
                'max' => 100,
            ],
            '%'  => [
                'min' => 0,
                'max' => 50,
            ],
        ],
        'selectors'  => [
            '{{WRAPPER}} .ac-social-links a' => 'border-radius: {{SIZE}}{{UNIT}};',
        ],
    ]
);

// Padding Control
$this->add_responsive_control(
    'social_icon_padding',
    [
        'label'      => __('Padding', 'your-plugin-textdomain'),
        'type'       => \Elementor\Controls_Manager::DIMENSIONS,
        'size_units' => ['px'],
        'selectors'  => [
            '{{WRAPPER}} .ac-social-links a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
    ]
);

// Margin Control
$this->add_responsive_control(
    'social_icon_margin',
    [
        'label'      => __('Margin', 'your-plugin-textdomain'),
        'type'       => \Elementor\Controls_Manager::DIMENSIONS,
        'size_units' => ['px'],
        'selectors'  => [
            '{{WRAPPER}} .ac-social-links a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
    ]
);


        $this->end_controls_section();
    }

    protected function render() {
        global $wpdb;
        $settings = $this->get_settings_for_display();
        $table = $wpdb->prefix . 'advanced_crud';
    
        // Pagination logic
        $paged = max(1, get_query_var('paged'));
        error_log("Paged Value (Elementor): " . $paged); // Debugging statement
        $offset = ($paged - 1) * $settings['per_page'];
    
        // Fetch entries with pagination
        $entries = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table ORDER BY created_at DESC LIMIT %d OFFSET %d",
            $settings['per_page'],
            $offset
        ));
    
        error_log("SQL Query (Elementor): SELECT * FROM $table ORDER BY created_at DESC LIMIT {$settings['per_page']} OFFSET $offset"); // Debugging statement
    
        $total_entries = $wpdb->get_var("SELECT COUNT(*) FROM $table");
        $total_pages = ceil($total_entries / $settings['per_page']);
          // Enqueue Font Awesome CDN if not already included
    if (!wp_style_is('font-awesome', 'enqueued')) {
        wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css');
    }

   // Render output
if ($entries) {
    echo '<div class="ac-entries-list">';
    foreach ($entries as $entry) {
        echo '<div class="ac-entry-item">';
        
        // Profile Image
        if ($settings['show_image'] === 'yes' && !empty($entry->profile_image)) {
            echo '<img src="' . esc_url($entry->profile_image) . '" class="ac-entry-image">';
        }

        echo '<div class="ac-entry-content" ">';
        echo '<h3 class="ac-entry-title">' . esc_html($entry->name) . '</h3>';
        echo '<p class="ac-entry-meta"><strong>Email:</strong> ' . esc_html($entry->email) . '</p>';
        echo '<p class="ac-entry-meta"><strong>Phone:</strong> ' . esc_html($entry->phone) . '</p>';
        echo '<p class="ac-entry-address">' . esc_html($entry->address) . '</p>';
        echo '<p class="ac-entry-description">' . esc_html($entry->description) . '</p>';

        // Social Links
        if ($settings['show_social'] === 'yes') {
            echo '<div class="ac-social-links" style="display: flex; gap: 10px; margin-top: 15px;">';

            if (!empty($entry->facebook)) {
                echo '<a href="' . esc_url($entry->facebook) . '" target="_blank"><i class="fab fa-facebook"></i></a>';
            }
            if (!empty($entry->instergram)) {
                echo '<a href="' . esc_url($entry->instergram) . '" target="_blank" ><i class="fab fa-instagram"></i></a>';
            }
            if (!empty($entry->youtube)) {
                echo '<a href="' . esc_url($entry->youtube) . '" target="_blank"><i class="fab fa-youtube"></i></a>';
            }
            if (!empty($entry->twitter)) {
                echo '<a href="' . esc_url($entry->twitter) . '" target="_blank" ><i class="fab fa-twitter"></i></a>';
            }
            if (!empty($entry->linkdin)) {
                echo '<a href="' . esc_url($entry->linkdin) . '" target="_blank" ><i class="fab fa-linkedin"></i></a>';
            }

            echo '</div>'; // Close social links div
        }

        echo '</div>'; // Close entry content div
        echo '</div>'; // Close entry item div
    }
    echo '</div>'; // Close entries list

    // Pagination links
    echo '<div class="ac-pagination" style="margin-top: 30px; display: flex; justify-content: center; gap: 5px;">';
    ac_pagination_bar($total_pages, $paged); // Call the pagination function
    echo '</div>';
} else {
    echo '<p>No entries found</p>';
}
    }
}
class AC_Form_Widget extends \Elementor\Widget_Base {

    public function get_name() { return 'ac_form'; }
    public function get_title() { return 'CRUD Form'; }
    public function get_icon() { return 'eicon-form-horizontal'; }
    public function get_categories() { return ['advanced-crud']; }

    protected function register_controls() {
        $this->start_controls_section('content_section', [
            'label' => 'Content',
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT
        ]);

        $this->add_control('form_title', [
            'label' => 'Form Title',
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => 'Add New Entry'
        ]);

        $this->end_controls_section();
    }

    protected function render() {
        global $wpdb;
        $table = $wpdb->prefix . 'advanced_crud';

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ac_nonce'])) {
            if (wp_verify_nonce($_POST['ac_nonce'], 'ac_form_nonce')) {
                $data = [
                    'name' => sanitize_text_field($_POST['ac_name']),
                    'email' => sanitize_email($_POST['ac_email']),
                    'address' => sanitize_textarea_field($_POST['ac_address']),
                    'phone' => sanitize_text_field($_POST['ac_phone']),
                    'profile_image' => esc_url_raw($_POST['ac_image']),
                    'created_at' => current_time('mysql')
                ];

                $wpdb->insert($table, $data);
                echo '<div class="ac-success">Entry added successfully!</div>';
            }
        }

        echo '<div class="ac-form-wrapper">';
        echo '<h3>' . esc_html($this->get_settings('form_title')) . '</h3>';
        echo '<form method="post">';
        wp_nonce_field('ac_form_nonce', 'ac_nonce');
        echo '<div class="ac-form-group">';
        echo '<input type="text" name="ac_name" placeholder="Full Name" required>';
        echo '</div>';
        echo '<div class="ac-form-group">';
        echo '<input type="email" name="ac_email" placeholder="Email Address" required>';
        echo '</div>';
        echo '<div class="ac-form-group">';
        echo '<textarea name="ac_address" placeholder="Address" required></textarea>';
        echo '</div>';
        echo '<div class="ac-form-group">';
        echo '<input type="tel" name="ac_phone" placeholder="Phone Number" required>';
        echo '</div>';
        echo '<div class="ac-form-group">';
        echo '<input type="url" name="ac_image" id="ac_image_url" placeholder="Image URL" required>';
        echo '<button type="button" class="ac-media-upload" data-target="#ac_image_url">Upload Image</button>';
        echo '</div>';
        echo '<button type="submit" class="ac-submit-button">Submit</button>';
        echo '</form></div>';
    }
}





\Elementor\Plugin::instance()->widgets_manager->register(new AC_Entries_Widget());
\Elementor\Plugin::instance()->widgets_manager->register(new AC_Form_Widget());