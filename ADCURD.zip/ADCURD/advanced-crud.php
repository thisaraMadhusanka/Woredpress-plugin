<?php
/*
Plugin Name: Advanced CRUD
Description: Advanced CRUD Operations with Social Media Integration
Version: 2.1
Author: Tm
*/
defined('ABSPATH') || exit;

// Database Setup
register_activation_hook(__FILE__, 'ac_create_table');
function ac_create_table() {
    global $wpdb;
    $table = $wpdb->prefix . 'advanced_crud';
    $charset = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        name varchar(100) NOT NULL,
        email varchar(100) NOT NULL,
        address text NOT NULL,
        description text NOT NULL,
        phone varchar(20) NOT NULL,
        instergram varchar(255) NOT NULL,
        facebook varchar(255) NOT NULL,
        youtube varchar(255) NOT NULL,
        linkdin varchar(255) NOT NULL,
        twitter varchar(255) NOT NULL,
        profile_image varchar(255) NOT NULL,
        other text NOT NULL,
        created_at datetime NOT NULL,
        PRIMARY KEY  (id)
    ) $charset;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Admin Interface
add_action('admin_menu', 'ac_admin_menu');
function ac_admin_menu() {
    add_menu_page(
        'Advanced CRUD',
        'Advanced CRUD',
        'manage_options',
        'advanced-crud',
        'ac_admin_interface',
        'dashicons-database',
        6
    );
}

function ac_admin_interface() {
    global $wpdb;
    $table = $wpdb->prefix . 'advanced_crud';

    // Handle CRUD operations
    if (isset($_POST['submit'])) {
        if (!wp_verify_nonce($_POST['_wpnonce'], 'ac_nonce')) wp_die('Security check failed');

        $data = [
            'name'          => sanitize_text_field($_POST['name']),
            'email'         => sanitize_email($_POST['email']),
            'address'       => sanitize_textarea_field($_POST['address']),
            'description' => sanitize_textarea_field($_POST['description']),
            'phone'         => sanitize_text_field($_POST['phone']),
            'instergram'    => esc_url_raw($_POST['instergram']),
            'facebook'      => esc_url_raw($_POST['facebook']),
            'youtube'      => esc_url_raw($_POST['youtube']),
            'linkdin'      => esc_url_raw($_POST['linkdin']),
            'twitter'       => esc_url_raw($_POST['twitter']),
            'profile_image' => esc_url_raw($_POST['profile_image']),
            'other' => sanitize_textarea_field($_POST['description']),
            'created_at'    => current_time('mysql')
        ];

        if (!empty($_POST['entry_id'])) {
            $wpdb->update($table, $data, ['id' => intval($_POST['entry_id'])]);
            echo '<div class="notice notice-success"><p>Entry updated!</p></div>';
        } else {
            $wpdb->insert($table, $data);
            echo '<div class="notice notice-success"><p>Entry created!</p></div>';
        }
    }

    // Handle deletion
    if (isset($_GET['action']) && $_GET['action'] === 'delete') {
        $wpdb->delete($table, ['id' => intval($_GET['id'])]);
        echo '<div class="notice notice-success"><p>Entry deleted!</p></div>';
    }

    // Get entry for editing
    $entry = null;
    if (isset($_GET['action']) && $_GET['action'] === 'edit') {
        $entry = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE id = %d", $_GET['id']
        ));
    }

    // Enqueue admin assets
    wp_enqueue_media();
    wp_enqueue_script('ac-admin-js', plugins_url('assets/js/admin.js', __FILE__), ['jquery'], '1.0', true);

    // Display interface
    include_once('admin-interface.php');
}

// Shortcode for Displaying Entries
add_shortcode('ac_entries', 'ac_entries_shortcode');
function ac_entries_shortcode($atts) {
    global $wpdb;
    $table = $wpdb->prefix . 'advanced_crud';

    // Parse shortcode attributes
    $atts = shortcode_atts([
        'per_page' => 5, // Default number of entries per page
        'show_image' => 'yes', // Default to show images
        'social_links' => 'yes' // Default to show social links
    ], $atts, 'ac_entries');

    $per_page = intval($atts['per_page']);
    $show_image = sanitize_text_field($atts['show_image']);
    $social_links = sanitize_text_field($atts['social_links']);

    // Pagination logic
    $paged = max(1, get_query_var('paged') ? get_query_var('paged') : get_query_var('page'));
    $offset = ($paged - 1) * $per_page;

    // Fetch entries
    $entries = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table ORDER BY created_at DESC LIMIT %d OFFSET %d",
        $per_page,
        $offset
    ));

    $total_entries = $wpdb->get_var("SELECT COUNT(*) FROM $table");
    $total_pages = ceil($total_entries / $per_page);

    // Enqueue Font Awesome CDN if not already included
    if (!wp_style_is('font-awesome', 'enqueued')) {
        wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css');
    }

    // Build output
    ob_start();
    if ($entries) {
        echo '<div class="ac-entries-list">';
        foreach ($entries as $entry) {
            echo '<div class="ac-entry-item">';
            if ($show_image === 'yes' && !empty($entry->profile_image)) {
                echo '<img src="' . esc_url($entry->profile_image) . '" class="ac-entry-image">';
            }
            echo '<div class="ac-entry-content">';
            echo '<h3 class="ac-entry-title">' . esc_html($entry->name) . '</h3>';
            echo '<p class="ac-entry-meta"><strong>Email:</strong> ' . esc_html($entry->email) . '</p>';
            echo '<p class="ac-entry-meta"><strong>Phone:</strong> ' . esc_html($entry->phone) . '</p>';
            echo '<p class="ac-entry-address"> ' . esc_html($entry->address) . '</p>';
            echo '<p class="ac-entry-description">' . esc_html($entry->description) . '</p>';
            echo '<p class="ac-entry-other">' . esc_html($entry->other) . '</p>';

            // Display social links if enabled
            if ($social_links === 'yes') {
                echo '<div class="ac-social-links" style="display: flex; gap: 10px; margin-top: 15px;">';
                if (!empty($entry->facebook)) {
                    echo '<a href="' . esc_url($entry->facebook) . '" target="_blank" style="display: inline-flex; align-items: center; justify-content: center; width: 36px; height: 36px; background-color: #f0f0f0; border-radius: 50%; text-decoration: none; transition: background-color 0.3s ease, color 0.3s ease; padding: 8px; color: #333;" onmouseover="this.style.backgroundColor=\'#0073aa\'; this.style.color=\'#fff\';" onmouseout="this.style.backgroundColor=\'#f0f0f0\'; this.style.color=\'#333\';"><i class="fab fa-facebook"></i></a>';
                }
                if (!empty($entry->instergram)) {
                    echo '<a href="' . esc_url($entry->instergram) . '" target="_blank" style="display: inline-flex; align-items: center; justify-content: center; width: 36px; height: 36px; background-color: #f0f0f0; border-radius: 50%; text-decoration: none; transition: background-color 0.3s ease, color 0.3s ease; padding: 8px; color: #333;" onmouseover="this.style.backgroundColor=\'#0073aa\'; this.style.color=\'#fff\';" onmouseout="this.style.backgroundColor=\'#f0f0f0\'; this.style.color=\'#333\';"><i class="fab fa-instagram"></i></a>';
                }
                if (!empty($entry->youtube)) {
                    echo '<a href="' . esc_url($entry->youtube) . '" target="_blank" style="display: inline-flex; align-items: center; justify-content: center; width: 36px; height: 36px; background-color: #f0f0f0; border-radius: 50%; text-decoration: none; transition: background-color 0.3s ease, color 0.3s ease; padding: 8px; color: #333;" onmouseover="this.style.backgroundColor=\'#0073aa\'; this.style.color=\'#fff\';" onmouseout="this.style.backgroundColor=\'#f0f0f0\'; this.style.color=\'#333\';"><i class="fab fa-youtube"></i></a>';
                }
                if (!empty($entry->twitter)) {
                    echo '<a href="' . esc_url($entry->twitter) . '" target="_blank" style="display: inline-flex; align-items: center; justify-content: center; width: 36px; height: 36px; background-color: #f0f0f0; border-radius: 50%; text-decoration: none; transition: background-color 0.3s ease, color 0.3s ease; padding: 8px; color: #333;" onmouseover="this.style.backgroundColor=\'#0073aa\'; this.style.color=\'#fff\';" onmouseout="this.style.backgroundColor=\'#f0f0f0\'; this.style.color=\'#333\';"><i class="fab fa-twitter"></i></a>';
                }
                if (!empty($entry->linkdin)) {
                    echo '<a href="' . esc_url($entry->linkdin) . '" target="_blank" style="display: inline-flex; align-items: center; justify-content: center; width: 36px; height: 36px; background-color: #f0f0f0; border-radius: 50%; text-decoration: none; transition: background-color 0.3s ease, color 0.3s ease; padding: 8px; color: #333;" onmouseover="this.style.backgroundColor=\'#0073aa\'; this.style.color=\'#fff\';" onmouseout="this.style.backgroundColor=\'#f0f0f0\'; this.style.color=\'#333\';"><i class="fab fa-linkedin"></i></a>';
                }
                echo '</div>'; // Close social links div
            }

            echo '</div>'; // Close entry content div
            echo '</div>'; // Close entry item div
        }
        echo '</div>'; // Close entries

        // Pagination
        echo '<div class="ac-pagination">';
        ac_pagination_bar($total_pages, $paged);
        echo '</div>';
    } else {
        echo '<p>No entries found.</p>';
    }

    return ob_get_clean();
}

// Pagination Function
function ac_pagination_bar($total_pages, $current_page) {
    $big = 999999999; // Need an unlikely integer for str_replace
    if ($total_pages > 1) {
        echo paginate_links([
            'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
            'format' => '?paged=%#%',
            'current' => $current_page,
            'total' => $total_pages,
            'prev_text' => __('« Previous'),
            'next_text' => __('Next »'),
        ]);
    }
}

// Elementor Integration
add_action('elementor/widgets/register', 'ac_register_widgets');
function ac_register_widgets() {
    require_once(__DIR__ . '/includes/elementor-widgets.php');
}

// Enqueue Assets
add_action('wp_enqueue_scripts', 'ac_enqueue_assets');
function ac_enqueue_assets() {
    wp_enqueue_style('ac-frontend', plugins_url('assets/css/frontend.css', __FILE__));
}

add_action('admin_enqueue_scripts', 'ac_admin_assets');
function ac_admin_assets($hook) {
    if ($hook === 'toplevel_page_advanced-crud') {
        wp_enqueue_style('ac-admin', plugins_url('assets/css/admin.css', __FILE__));
    }
}

// Elementor Category
add_action('elementor/elements/categories_registered', 'ac_elementor_category');
function ac_elementor_category($elements_manager) {
    $elements_manager->add_category('advanced-crud', [
        'title' => 'Advanced CRUD',
        'icon' => 'eicon-database'
    ]);
}


// Add this function to check for plugin updates
add_filter('pre_set_site_transient_update_plugins', 'check_for_plugin_updates');

function check_for_plugin_updates($transient) {
    // Plugin details
    $plugin_slug = 'advanced-crud'; // Replace with your plugin's folder name
    $plugin_file = $plugin_slug . '/advance-curd.php'; // Replace with your main plugin file

    // Remote update manifest URL
    $remote_url = 'https://yourwebsite.com/update.json'; // Replace with your JSON file URL

    // Fetch the remote update manifest
    $response = wp_remote_get($remote_url);

    if (!is_wp_error($response) && $response['response']['code'] == 200) {
        $data = json_decode($response['body'], true);

        if (isset($data['version']) && isset($data['download_link'])) {
            // Get the current version of the plugin
            $current_version = get_file_data(WP_PLUGIN_DIR . '/' . $plugin_file, ['Version' => 'Version'], false)['Version'];

            // Compare versions
            if (version_compare($data['version'], $current_version, '>')) {
                // New version available
                $transient->response[$plugin_file] = (object)[
                    'slug' => $plugin_slug,
                    'new_version' => $data['version'],
                    'url' => $data['homepage'],
                    'package' => $data['download_link']
                ];
            }
        }
    }

    return $transient;
}

// Add this function to provide plugin information for the update process
add_filter('plugins_api', 'provide_plugin_info', 10, 3);

function provide_plugin_info($res, $action, $args) {
    if ($action === 'plugin_information' && isset($args->slug) && $args->slug === 'advanced-crud') {
        $remote_url = 'https://yourwebsite.com/update.json'; // Replace with your JSON file URL
        $response = wp_remote_get($remote_url);

        if (!is_wp_error($response) && $response['response']['code'] == 200) {
            $data = json_decode($response['body'], true);
            return (object)$data;
        }
    }

    return $res;
}


wp_enqueue_script('ac-admin-js', plugins_url('assets/js/admin.js', __FILE__), ['jquery'], '1.0', true);