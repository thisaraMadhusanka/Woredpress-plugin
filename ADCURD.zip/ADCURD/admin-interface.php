<?php
global $wpdb;
$table = $wpdb->prefix . 'advanced_crud';
$entry = isset($_GET['action']) && $_GET['action'] === 'edit' ? 
    $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $_GET['id'])) : 
    null;

// Pagination logic
$per_page = 10; // Number of entries per page
$current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
$offset = ($current_page - 1) * $per_page;

$total_entries = $wpdb->get_var("SELECT COUNT(*) FROM $table");
$total_pages = ceil($total_entries / $per_page);

$entries = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM $table ORDER BY created_at DESC LIMIT %d OFFSET %d",
    $per_page,
    $offset
));
?>



<div class="wrap ac-admin-wrap">
    <h1 style="padding:20px;">Advanced CRUD</h1>
    
    <div class="ac-admin-form">
        <h2><?= $entry ? 'Edit Entry' : 'Add New Entry' ?></h2>
        <form id="crud-form" method="post">
            <?php wp_nonce_field('ac_nonce'); ?>
            <input type="hidden" name="entry_id" value="<?= $entry->id ?? '' ?>">
            
            <div class="ac-form-group">
                <label>Name</label>
                <input type="text" name="name" required 
                    value="<?= esc_attr($entry->name ?? '') ?>">
            </div>
            
            <div class="ac-form-group">
                <label>Email</label>
                <input type="email" name="email" required 
                    value="<?= esc_attr($entry->email ?? '') ?>">
            </div>
            
            <div class="ac-form-group">
                <label>Address</label>
                <textarea name="address" required><?= esc_textarea($entry->address ?? '') ?></textarea>
            </div>

            <div class="ac-form-group">
                <label>Description</label>
                <textarea name="description" required><?= esc_textarea($entry->description ?? '') ?></textarea>
            </div>
            
            <div class="ac-form-group">
                <label>Phone</label>
                <input type="text" name="phone" required 
                    value="<?= esc_attr($entry->phone ?? '') ?>">
            </div>

            <div class="ac-form-group">
                <label>Facebook</label>
                <input type="url" name="facebook" 
                    value="<?= esc_attr($entry->facebook ?? '') ?>">
            </div>

            <div class="ac-form-group">
                <label>Instagram</label>
                <input type="url" name="instergram" 
                    value="<?= esc_attr($entry->instergram ?? '') ?>">
            </div>

            <div class="ac-form-group">
                <label>YouTube</label>
                <input type="url" name="youtube" 
                    value="<?= esc_attr($entry->youtube ?? '') ?>">
            </div>

            <div class="ac-form-group">
                <label>Twitter</label>
                <input type="url" name="twitter" 
                    value="<?= esc_attr($entry->twitter ?? '') ?>">
            </div>

            <div class="ac-form-group">
                <label>LinkedIn</label>
                <input type="url" name="linkdin" 
                    value="<?= esc_attr($entry->linkdin ?? '') ?>">
            </div>
            
            <div class="ac-form-group">
                <label>Profile Image</label>
                <div class="ac-image-uploader">
                    <input type="text" name="profile_image" id="ac_image_url" 
                        value="<?= esc_url($entry->profile_image ?? '') ?>">
                    <button type="button" class="button ac-media-upload">Upload Image</button>
                </div>
            </div>
            
            <div class="ac-form-group">
                <label>Others</label>
                <textarea name="other" required><?= esc_textarea($entry->other ?? '') ?></textarea>
            </div>
            

            <button type="submit" name="submit" class="button button-primary" style="margin-top: 20px;">
                <?= $entry ? 'Update' : 'Create' ?> Entry
            </button>
        </form>
    </div>
    <div class="ac-admin-table" style="padding:20px;">
    <h2>All Entries</h2>
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Image</th>
                <th>Social</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($entries as $item) : ?>
            <tr>
                <td><?= $item->id ?></td>
                <td><?= esc_html($item->name) ?></td>
                <td><?= esc_html($item->email) ?></td>
                <td><?= esc_html($item->phone) ?></td>
                <td><img src="<?= esc_url($item->profile_image) ?>" style="max-width: 50px;"></td>
                <td>
                    <?php if (!empty($item->facebook)) : ?>
                        <a href="<?= esc_url($item->facebook) ?>" target="_blank">
                            <img src="https://cdn-icons-png.flaticon.com/512/145/145802.png" width="20" title="Facebook">
                        </a>
                    <?php endif; ?>
                    <?php if (!empty($item->instergram)) : ?>
                        <a href="<?= esc_url($item->instergram) ?>" target="_blank">
                            <img src="https://cdn-icons-png.flaticon.com/512/2111/2111463.png" width="20" title="Instagram">
                        </a>
                    <?php endif; ?>
                    <?php if (!empty($item->youtube)) : ?>
                        <a href="<?= esc_url($item->youtube) ?>" target="_blank">
                            <img src="https://cdn-icons-png.flaticon.com/512/1384/1384060.png" width="20" title="YouTube">
                        </a>
                    <?php endif; ?>
                    <?php if (!empty($item->twitter)) : ?>
                        <a href="<?= esc_url($item->twitter) ?>" target="_blank">
                            <img src="https://cdn-icons-png.flaticon.com/512/733/733635.png" width="20" title="Twitter">
                        </a>
                    <?php endif; ?>
                    <?php if (!empty($item->linkdin)) : ?>
                        <a href="<?= esc_url($item->linkdin) ?>" target="_blank">
                            <img src="https://cdn-icons-png.flaticon.com/512/145/145807.png" width="20" title="LinkedIn">
                        </a>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="?page=advanced-crud&action=edit&id=<?= $item->id ?>" class="button">Edit</a>
                    <a href="?page=advanced-crud&action=delete&id=<?= $item->id ?>" 
                       class="button button-danger" 
                       onclick="return confirm('Are you sure?')">Delete</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="ac-pagination">
        <?php
        echo paginate_links([
            'base' => add_query_arg('paged', '%#%'),
            'format' => '',
            'prev_text' => __('&laquo; Previous'),
            'next_text' => __('Next &raquo;'),
            'total' => $total_pages,
            'current' => $current_page
        ]);
        ?>
    </div>
</div>



<div class="ac-shortcode-section">
    <h2>Shortcodes</h2>
    <p>Use the following shortcodes to display CRUD widgets on your site:</p>
    <ul>
        <li><strong>Entries List:</strong> <code>[ac_entries per_page="5" show_image="yes" social_links="yes"]</code></li>
        <!-- <li><strong>CRUD Form:</strong> <code>[ac_form]</code></li> -->
    </ul>
</div>

<!-- <script>
function clearFormFields(event) {
    event.preventDefault(); // Prevent default form submission
    
    let form = document.getElementById('crud-form');

    // Submit the form via JavaScript
    let formData = new FormData(form);
    fetch(window.location.href, {
        method: 'POST',
        body: formData
    }).then(response => {
        if (response.ok) {
            form.reset(); // Clear all fields after successful submission
            alert('Form submitted successfully!');
            window.location.href = "admin.php?page=advanced-crud"; // Redirect back to the page
        }
    }).catch(error => console.error('Error:', error));
}
</script> -->
